<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Consulta de Productos</title>
</head>
<body>
<h1 ALIGN=CENTER>CONSULTA PRODUCTOS</h1>
<center>
<table width="900" border="1">
<tr>
    <td>NUMERO DE REGISTRO</td>
    <td>NOMBRE DEL PRODUCTO</td>
    <td>CANTIDAD DE ENTRADA</td>
    <td>CANTIDAD DE SALIDA</td>
    <td>FECHA</td>
    <td>EXISTENCIA</td>
</tr>

<?php
    include("..\conexion.php");
    $query = "SELECT inventario.I_Num_Registro, I_Nomb_producto, I_Cantidad_Entrada, I_Cantidad_Salida, I_Fecha, I_Existencia
              FROM inventario
              ORDER BY 1";

    $result = mysqli_query($link, $query) or die("error en la consulta de productos");

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td><td>$row[5]</td>";
            echo "</tr>";
        }
    } else {
        echo "La consulta no encontró registros asociados";
    }

    echo "<script>
        function redireccionar() {
            var pagina='../index.html';
            location.href = pagina;
        }
        setTimeout('redireccionar()', 10000);
    </script>";
?>
</table>
</body>
</html>