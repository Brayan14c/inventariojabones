<?php
   /*  Este software se hizo para el resultado de aprendizaje CRUD 
   Elaboro:  Víctor J. Rodríguez P.
   Para que entiendan como se actualiza, borra, inserta, en una base de datos en Xampp 
   Se deben tener concentos claros ya de Php, mysql, html, css, java script  */
	   
	include("..\conexion.php");
	$accion=$_POST["Accion"];
 //   $Codigop=$_GET['codigo'];
	if(isset($accion))
	{
		if($accion=="Update")
		{
			//echo"Enviado desde actualizaci�n";
			$query="UPDATE inventario
					SET I_Nomb_producto = '".$_POST['txtnombre']."',
						I_Cantidad_Entrada = '".$_POST['txtCantEnt']."',
						I_Cantidad_Salida = '".$_POST['txtCantSal']."',
						I_Fecha= '".$_POST['date']."'
                        I_Existencia= '".$_POST['txtExistencia']."'
						WHERE inventario.I_Num_Registro = '".$_POST['txtcodigo']."'";
			$result=mysqli_query($link,$query) or die ("Error en la actualizacion de los datos. Error: ");
			echo "<script>
					alert('Los datos fueron actualizados correctamente');
					location.href='../index.html';
					</script>";
		}
		else
		{
			
			//echo "El codigo es $Numerop ";
			//echo "El codigo es $Codigop ";
			//echo"Enviado desde eliminacion";
			$query="DELETE 
					FROM inventario
					WHERE  = codigo '".$_POST['txtcodigo']."'";
			$result=mysqli_query($link,$query) or die ("Error en el borrado de los datos. Error: ");
			echo "<script>
					alert('Los datos fueron borrados correctamente');
					location.href='../index.html';
					</script>";
		} 
	}
?>