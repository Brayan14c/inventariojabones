<?php
include("..\conexion.php");
/*  Este software se hizo para el resultado de aprendizaje CRUD 
   Elaboro:  Víctor J. Rodríguez P.
   Para que entiendan como se actualiza, borra, inserta, en una base de datos en Xampp 
   Se deben tener concentos claros ya de Php, mysql, html, css, java script  */

	$Numerop=$_GET['codigo'];
	$query="SELECT * FROM inventario WHERE I_Num_Registro = '".$Numerop."'";
	$result=mysqli_query($link,$query) or die ("Error en la consulta de inventario. Error: ");
	if(mysqli_num_rows($result)>0)
	{
		while($Rs=mysqli_fetch_array($result))
		{
			?>
			<center>
			<form method=POST name=frm action="grabaractualiza.php">
				<table width=400 border=1>
				<tr>
				<td colspan=2 align=CENTER>
					<h3>FORMULARIO DE ELIMINACION</h3>
				</td>
				</tr>
				
				<td width=50%>Num_Registro</td>
      <td>
        <input name="txtcodigo" type="text" id="txtcodigo" size=5/>
      </td>
    </tr>
    <tr>
      <td>Nombre</td>
      <td>
        <input name="txtnombre" type="text" id="txtnombre" size=30/>
      </td>
    </tr>
	<tr>
    <td>Cantidad de Entrada</td>
      <td>
        <input name="txtCantEnt" type="text" id="txtCantEnt" size=5/>
      </td>
    </tr>
	<tr>
      <td>Cantidad de Salida</td>
      <td>
        <input name="txtCantSal" type="text" id="txtCantSal" size=12/>
      </td>
    </tr>
    <td>fecha</td>
      <td>
        <input name="date" type="text" id="date" size=12/>
      </td>
    </tr>
    <td>Existencia</td>
      <td>
        <input name="txtExistencia" type="text" id="txtExistencia" size=12/>
      </td>
    <tr>
								
			<tr>
				  <td>
					<center>
						<input type="submit" name="Submit" value="Enviar" />
					</center>
				  </td>
				  <td>
					<center>
						<input type="reset" name="Submit2" value="Restablecer" />
					</center>
				  </td>
				</tr>
			
				</table>
					
				<input type="hidden" name="Accion" value="Delete" />
				
			</form>
			</center>
			<?php
		}
	}
	mysqli_close($link);
?>