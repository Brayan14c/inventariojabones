
<script>

function validar(formulario)
{

if(formulario.txtcodigo.value=='')
{
alert('Sr Usuario debe ingresar el codigo');
formulario.txtcodigo.focus();
return false;
}
else if (isNaN(formulario.txtcodigo.value))
{
alert("El codigo ingresado no es un n�mero");
formulario.txtcodigo.focus();
return false;
}

if(formulario.txtnombre.value=='')
{
alert('Sr Usuario debe ingresar el(los) nombre(s)');
formulario.txtnombre.focus();
return false;
}

return true;
}
</script>




<?php
	include("..\conexion.php");

	$Codigop=$_GET['codigo'];
		
	
	$query="SELECT * FROM inventario WHERE inventario.I_Num_Registro =  ' " .$Codigop."  '  " ;
	$result=mysqli_query($link,$query) or die ("Error en la consulta de productos. Error: ");
	if(mysqli_num_rows($result) > 0)
	{
         $Rs=mysqli_fetch_array($result)
			
					?>
			<center>
			<form method=POST name=frm onsubmit="return validar(this)" action="grabaractualiza.php">
				
	  <table width="400" border="1">
	    <tr>
        <td width=50%>Num_Registro</td>
      <td>
        <input name="txtcodigo" type="text" id="txtcodigo" size=5/>
      </td>
    </tr>
    <tr>
      <td>Nombre</td>
      <td>
        <input name="txtnombre" type="text" id="txtnombre" size=30/>
      </td>
    </tr>
	<tr>
    <td>Cantidad de Entrada</td>
      <td>
        <input name="txtCantEnt" type="text" id="txtCantEnt" size=5/>
      </td>
    </tr>
	<tr>
      <td>Cantidad de Salida</td>
      <td>
        <input name="txtCantSal" type="text" id="txtCantSal" size=12/>
      </td>
    </tr>
    <td>fecha</td>
      <td>
        <input name="date" type="text" id="date" size=12/>
      </td>
    </tr>
    <td>Existencia</td>
      <td>
        <input name="txtExistencia" type="text" id="txtExistencia" size=12/>
      </td>
    <tr>
	

    <tr>
    <tr>
      <td>
     
	<center>
        <input type="submit" name="Submit" value="Enviar" />
		</center>
      </td>
      <td>
	<center>
        <input type="reset" name="Submit2" value="Restablecer" />
		</center>
      </td>
    </tr>
  </table>

<input type="hidden" name="Accion" value="Update" />
				
			</form>
			</center>
<?php
	
	}
	// mysqli_close();
	mysqli_close($link);
?>