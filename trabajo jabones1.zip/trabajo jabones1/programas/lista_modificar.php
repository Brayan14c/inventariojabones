<html>


<head>


</head>


<body>
<link rel="stylesheet" href="index.css">
</body>




<center>

<?php
	Include("..\conexion.php");
	$query="Select *
	        From inventario
	Order by I_Num_registro";
	$result=mysqli_query($link,$query) or die("Error en la consulta de inventario. Error: ");
	if(mysqli_num_rows($result)>0)
	{
		?>
		<table border=1>
			<tbody>
			<tr>
            <td>NUMERO DE REGISTRO</td>
            <td>NOMBRE DEL PRODUCTO</td>
            <td>CANTIDAD DE ENTRADA</td>
            <td>CANTIDAD DE SALIDA</td>
            <td>FECHA</td>
            <td>EXISTENCIA</td>
			<td>ACCION A REALIZAR</td>
			</tr>
			<?php	
			while($Rs=mysqli_fetch_array($result))
			{
				echo "<tr>".
					 "<td>".$Rs['I_Num_Registro']."</td>".
					 "<td>".$Rs['I_Nomb_producto']."</td>".
					 "<td>".$Rs['I_Cantidad_Entrada']."</td>".
					 "<td>".$Rs['I_Cantidad_Salida']."</td>".
					 "<td>".$Rs['I_Fecha']."</td>".
                     "<td>".$Rs['I_Existencia']."</td>".
					 "<td><a href=modificar.php?codigo=".$Rs['I_Num_Registro'].">Actualizar/</a>
					 <a href=eliminar.php?codigo=".$Rs['I_Num_Registro'].">Eliminar</a></td>".
					 "</tr>";
			}
	}
	else
	{
		echo"No hay productos registrados para listar";
	}
	mysqli_close($link);
	?>
	</table>
</center>	
</html>