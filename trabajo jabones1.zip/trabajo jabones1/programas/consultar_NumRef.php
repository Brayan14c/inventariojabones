<html>

	<head>
	<style>
body{
	margin-top: 20%;
    background-image: url("img/fondo.jpeg");
    background-size: cover;
    background-repeat: no-repeat;
    background-attachment: fixed;
  }

  form{
  	width:400px;
	padding:16px;
	border-radius:10px;
	margin:auto;
	background-color:#ccc;
  }


table input{
	width:80px;
	font-weight:bold;
	display:inline-block;
	background-color: transparent;
}

.white-button {
    background-color: white;
    color: black; 
}

		</style>

	</head>
	<body>
			
			</body>
</html>

<script>



function validar(formulario)
{
	if(form1.txtcodigo.value=='')
	{
		alert('Sr Usuario debe ingresar el codigo del Estudiante a consultar');
		formulario.txtcodigo.focus();
		return false;
	}
	else if (isNaN(form1.txtcodigo.value))
	{
		alert("El valor ingresado no es un n�mero");
		formulario.txtcodigo.focus();
		return false;
	}
	return true;
}
</script>
<center>
<form id="form1" name="form1" method=post onsubmit="return validar(this)" action="consultarNumpro.php">
  <table width="400" border="1">
    <tr>
      <td width=100%>INGRESE EL CODIGO A CONSULTAR</td>
      <td>
        <input name="txtcodigo" type="text" id="txtcodigo" size=25/>
      </td>
    </tr>
    <tr>
      <td>
	<center>
           <input type="submit" name="Submit" value="Consultar" class="white-button"/>
		</center>
      </td>

      <td>
	<center>
        <input type="reset" name="Submit2" value="Limpiar" class="white-button" />
		</center>
      </td>
    </tr>
  </table>

</form>
</center>