<?php


$numreg=$_POST['txtcodigo'];
$nombre=$_POST["txtnombre"];
$CantEnt=$_POST["txtCantEnt"]; 
$CantSal=$_POST["txtCantSal"]; 
$fecha=$_POST['date'];
$existe=$_POST["txtExistencia"];

include("..\conexion.php");

$query = "INSERT INTO `inventario` (`I_Num_Registro`,`I_Nomb_producto`,`I_Cantidad_Entrada`,`I_Cantidad_Salida`,`I_Fecha`,`I_Existencia`)
VALUES ('$numreg','$nombre','$CantEnt','$CantSal','$fecha','$existe')";

$cadena=mysqli_query($link,$query) or die ("Error en la insercion de datos");

echo "<script>
 
alert('Los datos se grabaron correctamente');

location.href='../index.html';

</script>";

?>