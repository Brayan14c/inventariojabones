<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>INVENTARIO DE LOS PRODUCTOS</title>

<script>


function validar(formulario)
{

if(formulario.txtcodigo.value=='')
{
alert('Sr Usuario debe ingresar el codigo');
formulario.txtcodigo.focus();
return false;
}

if (isNaN(formulario.txtcodigo.value))
{
alert("El codigo ingresado no es un n�mero");
formulario.txtcodigo.focus();
formulario.txtcodigo.value='';
return false;
}

if(formulario.txtnombre.value=='')
{
alert('Sr Usuario debe ingresar la descripcion');
formulario.txtnombre.focus();
return false;
}

if(formulario.txtCantEnt.value=='')
{
alert('Sr Usuario debe ingresar la cantidad');
formulario.txtCantEnt.focus();
formulario.txtCantEnt.value='';
return false;
}

if(formulario.txtCantsal.value=='')
{
alert('Sr Usuario debe ingresar un valor');
formulario.txtCantSal.focus();
formulario.txtCantSal.value='';
return false;
}



if(formulario.cmbundmedida.value==0)
{
alert('Sr Usuario debe seleccionar una unidad de medida');
formulario.cmbundmedida.focus();
return false;
}

return true;
}

</script>

<h1 ALIGN=CENTER>ENTRA DATOS DE PRODUCTOS</h1>

<style>
  body{
    background-image: url("img/fondo.jpeg");
    background-size: cover;
    background-repeat: no-repeat;
    background-attachment: fixed;
  }

  form{
  width:400px;
	padding:16px;
	border-radius:10px;
	margin:auto;
	background-color:#ccc;
  }


table input{
	width:60%;
	font-weight:bold;
	display:inline-block;
	background-color: transparent;
}

.white-button {
    background-color: white;
    color: black; 

}


</style>


</head>

<body >
    


<center>

<form id="form1" name="form1" method=post onsubmit="return validar(this)" action="guardarinventario.php">

  <table width="400" border="1">
    <tr>
      <td width=50%>Num_Registro</td>
      <td>
        <input name="txtcodigo" type="text" id="txtcodigo" size=5/>
      </td>
    </tr>
    <tr>
      <td>Nombre</td>
      <td>
        <input name="txtnombre" type="text" id="txtnombre" size=30/>
      </td>
    </tr>
	<tr>
    <td>Cantidad de Entrada</td>
      <td>
        <input name="txtCantEnt" type="text" id="txtCantEnt" size=5/>
      </td>
    </tr>
	<tr>
      <td>Cantidad de Salida</td>
      <td>
        <input name="txtCantSal" type="text" id="txtCantSal" size=12/>
      </td>
    </tr>
    <td>fecha</td>
      <td>
        <input name="date" type="text" id="date" size=12/>
      </td>
    </tr>
    <td>Existencia</td>
      <td>
        <input name="txtExistencia" type="text" id="txtExistencia" size=12/>
      </td>
    <tr>
    
      
    <?php
		include("../conexion.php");
		
		?> 
    </tr>
	
 
    <tr>
      <td>
     
	<center>
        <input type="submit" name="Submit" value="Enviar" class="white-button"/>
		</center>
      </td>
      <td>
	<center>
        <input type="reset" name="Submit2" value="Restablecer" class="white-button"/>
		</center>

  </td>
    </tr> 
  </table>
</form>
</center>


</body>
</html>