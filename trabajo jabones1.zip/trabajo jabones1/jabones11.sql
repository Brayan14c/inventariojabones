-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-09-2023 a las 18:33:08
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `jabones11`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `facturación`
--

CREATE TABLE `facturación` (
  `F_Num_Facturacion` int(12) NOT NULL ,
  `F_Fecha` date NOT NULL,
  `F_Cantidad` varchar(50) NOT NULL,
  `F_Valor_Unidad` float NOT NULL,
  `F_Sub_Total` float NOT NULL,
  `F_IVA` float NOT NULL,
  `F_Total` float NOT NULL,
  `F_Tipo _Factura` varchar(50) NOT NULL,
  `UC_Cod_Cliente` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `facturación`
--

INSERT INTO `facturación` (`F_Num_Facturacion`, `F_Fecha`, `F_Cantidad`, `F_Valor_Unidad`, `F_Sub_Total`, `F_IVA`, `F_Total`, `F_Tipo _Factura`, `UC_Cod_Cliente`) VALUES
(800123, '2006-03-17', '120000', 20000, 120000, 19, 240000, 'normal', 3),
(800124, '2006-06-09', '60000', 6000, 60000, 19, 120000, 'normal', 4),
(800125, '2006-09-23', '178000', 17800, 178000, 19, 256000, 'normal', 1),
(800126, '2006-07-07', '665000', 66000, 665000, 19, 1330000, 'electronica', 2),
(800127, '2006-05-05', '98050', 9850, 98050, 19, 196000, 'normal', 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `formulas`
--

CREATE TABLE `formulas` (
  `FL_Num_Formula` int(12) NOT NULL,
  `FL_Cantidad` varchar(50) NOT NULL,
  `FL_Nomb_Formula` varchar(50) NOT NULL,
  `P_Cod_Producto` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `formulas`
--

INSERT INTO `formulas` (`FL_Num_Formula`, `FL_Cantidad`, `FL_Nomb_Formula`, `P_Cod_Producto`) VALUES
(1, '2', 'jabon coco', 2),
(2, '1', 'jabon de carbon', 2),
(3, '1', 'jabon de hiervas', 3),
(4, '3', 'jabon de marihuana', 4),
(5, '2', 'jabon de frutos rojos', 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `I_Num_Registro` int(12) NOT NULL,
  
  `I_Cantidad _Entrada` varchar(50) NOT NULL,
  `I_Cantidad _Salida` varchar(50) NOT NULL,
  `I_Fecha` date NOT NULL,
  `I_Existencia` varchar(50) NOT NULL,
  `F_Num_Facturacion` int(12) NOT NULL,
  `P_Cod_Producto` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `inventario`
--

INSERT INTO `inventario` (`I_Num_Registro`, `I_Cantidad _Entrada`, `I_Cantidad _Salida`, `I_Fecha`, `I_Existencia`, `F_Num_Facturacion`, `P_Cod_Producto`) VALUES
(121107000, '50', '25', '2023-03-23', '25', 800123, 1),
(121107001, '50', '25', '2023-05-11', '25', 800124, 2),
(121107002, '50', '25', '2023-07-15', '25', 800125, 3),
(121107003, '50', '25', '2023-06-21', '25', 800126, 4),
(121107004, '50', '25', '2023-09-10', '25', 800127, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario_materia_prima`
--

CREATE TABLE `inventario_materia_prima` (
  `IMP_Num_regis_Mat_prima` int(12) NOT NULL,
  `IMP_Cant_Entrada` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `IMP_Cant_Salida` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `IMP_Fecha` date NOT NULL,
  `IMP_Existencia` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `IMP_Num_Factura` int(12) NOT NULL,
  `UA_Cod_administrativo` int(12) NOT NULL,
  `UP_Cod_Provedor` int(12) NOT NULL,
  `MP_Cod_Mat_Prim` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;

--
-- Volcado de datos para la tabla `inventario_materia_prima`
--

INSERT INTO `inventario_materia_prima` (`IMP_Num_regis_Mat_prima`, `IMP_Cant_Entrada`, `IMP_Cant_Salida`, `IMP_Fecha`, `IMP_Existencia`, `IMP_Num_Factura`, `UA_Cod_administrativo`, `UP_Cod_Provedor`, `MP_Cod_Mat_Prim`) VALUES
(136233000, '10', '5', '2023-03-23', '5', 99100, 2, 2, 1),
(136233001, '10', '5', '2023-03-23', '5', 100101, 2, 5, 2),
(136233002, '10', '5', '2023-05-11', '5', 100102, 2, 2, 3),
(136233003, '10', '5', '2023-05-11', '5', 100103, 2, 5, 4),
(136233004, '10', '5', '2023-07-15', '5', 100104, 2, 2, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materias primas`
--

CREATE TABLE `materias primas` (
  `MP_Cod_Mat_Prim` int(12) NOT NULL,
  `MP_Nombre` varchar(50) NOT NULL,
  `MP_Descripción` varchar(50) NOT NULL,
  `MP_Valor` float NOT NULL,
  `MP_Referencia` varchar(50) NOT NULL,
  `IMP_Num_regis_Mat_prima` int(12) NOT NULL,
  `FL_Num_Formula` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `materias primas`
--

INSERT INTO `materias primas` (`MP_Cod_Mat_Prim`, `MP_Nombre`, `MP_Descripción`, `MP_Valor`, `MP_Referencia`, `IMP_Num_regis_Mat_prima`, `FL_Num_Formula`) VALUES
(1, 'aceites', 'Aceites que hacen que el jabón sale más duro son', 20000, 'medida en kilogramos', 1, 1),
(2, 'disolventes', 'Sera todo aquel', 20000, 'medida en kilogramos', 1, 1),
(3, 'ceites esenciales', 'el único aceite que se puede usar en solitario es ', 20000, 'medida en kilogramos', 2, 1),
(4, 'pigmentos', 'Los colorantes líquidos son ideales si estás comen', 20000, 'medida en kilogramos', 2, 1),
(5, 'emulsionantes', 'se obtienen a partir de aceites y mantecas', 20000, 'medida en kilogramos', 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producción`
--

CREATE TABLE `producción` (
  `PCC_Cod_Produccion` int(12) NOT NULL,
  `PCC_Cantidad` int(12) NOT NULL,
  `PCC_Referencia` varchar(50) NOT NULL,
  `PCC_Fecha` date NOT NULL,
  `IMP_Num_regis_Mat_prima` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `producción`
--

INSERT INTO `producción` (`PCC_Cod_Produccion`, `PCC_Cantidad`, `PCC_Referencia`, `PCC_Fecha`, `IMP_Num_regis_Mat_prima`) VALUES
(3, 10, 'jabon de coco', '2023-03-23', 1),
(6, 10, 'jabon de marihuana', '2023-05-11', 2),
(9, 10, 'jabon de carbon', '2023-07-15', 3),
(12, 10, 'jabon de hiervas', '2023-06-21', 4),
(15, 10, 'jabon de frutos rojos', '2023-09-10', 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `P_Cod_Producto` int(12) NOT NULL,
  `P_Nomb_Producto` varchar(50) NOT NULL,
  `P_Cantidad` int(12) NOT NULL,
  `P_Fecha` date NOT NULL,
  `UA_Cod_administrativo` int(12) NOT NULL,
  `PCC_Cod_Produccion` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`P_Cod_Producto`, `P_Nomb_Producto`, `P_Cantidad`, `P_Fecha`, `UA_Cod_administrativo`, `PCC_Cod_Produccion`) VALUES
(1, 'jabon de coco', 50, '2023-08-12', 2, 0),
(2, 'jabon de carbon', 50, '2023-08-12', 2, 0),
(3, 'jabon de hiervas', 50, '2023-08-12', 2, 0),
(4, 'jabon de marihuana', 50, '2023-08-12', 2, 0),
(5, 'jabon de frutos rojos', 50, '2023-08-12', 2, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol usuario`
--

CREATE TABLE `rol usuario` (
  `RU_Cod_Rol` int(15) NOT NULL,
  `RU_Nomb_rol` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `rol usuario`
--

INSERT INTO `rol usuario` (`RU_Cod_Rol`, `RU_Nomb_rol`) VALUES
(1, 'jefe'),
(2, 'administrador'),
(3, 'vendedor'),
(4, 'cajero'),
(5, 'conductor');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario-administrativo`
--

CREATE TABLE `usuario-administrativo` (
  `UA_Nomb_usuario` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `UA_Direción` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `UA_Correo_Electronico` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `UA_Contraseña` int(12) NOT NULL,
  `UA_Telefono` int(12) NOT NULL,
  `UA_Cod_administrativo` int(12) NOT NULL,
  `Cod_rol` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;

--
-- Volcado de datos para la tabla `usuario-administrativo`
--

INSERT INTO `usuario-administrativo` (`UA_Nomb_usuario`, `UA_Direción`, `UA_Correo_Electronico`, `UA_Contraseña`, `UA_Telefono`, `UA_Cod_administrativo`, `Cod_rol`) VALUES
('Hadrian', 'Cra. 71 #3a-69', 'hadri85@gmail.com', 0, 852741963, 1, 1),
('Brenan', 'Cra. 78a', 'bre11@gmail.com', 0, 123456789, 2, 3),
('Diego', 'Cra. 36 #25b-12', 'die@gmail.com', 0, 987654312, 3, 5),
('Gregorio', 'Cra. 64 #4b-67', 'grego966@gmail.como', 0, 846213359, 4, 4),
('Eladi', 'Cl 37c Sur #474', 'ela@gmail.com', 0, 159357864, 5, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_cliente`
--

CREATE TABLE `usuario_cliente` (
  `UC_Cod_Cliente` int(12) NOT NULL,
  `UC_Nomb_Usuario` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `UC_Correo_Electronico` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `UC_Contraseña` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `UC_Telefono` int(12) NOT NULL,
  `UC_Direción` varchar(50) COLLATE utf32_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;

--
-- Volcado de datos para la tabla `usuario_cliente`
--

INSERT INTO `usuario_cliente` (`UC_Cod_Cliente`, `UC_Nomb_Usuario`, `UC_Correo_Electronico`, `UC_Contraseña`, `UC_Telefono`, `UC_Direción`) VALUES
(1, 'ANNY', 'anny@gmail.com', 'annY1206', 2147483647, 'calle 80 sur 90-17'),
(2, 'DANIEL', 'NBA@gmail.com', 'negro33', 2147483644, 'carrera 120 # 85-45'),
(3, 'ARON', 'aron@gmail.com', 'rolon1423', 1234567891, 'avenida calle 68 #116-46'),
(4, 'JORGE', 'duquerestrepo@gmail.com', 'jojos10', 2147483647, 'diagonal 17b #112-05'),
(5, 'NATALY', 'enana@gmail.com', 'correr10', 2147483647, 'calle 75 #90-65');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_proveedor`
--

CREATE TABLE `usuario_proveedor` (
  `UP_Cod_Proveedor` int(12) NOT NULL,
  `UP_Direción` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `UP_Telefono` int(12) NOT NULL,
  `UP_Contraseña` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `UP_Correo_Electronico` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `UP_Nomb_Usuario` varchar(50) COLLATE utf32_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;

--
-- Volcado de datos para la tabla `usuario_proveedor`
--

INSERT INTO `usuario_proveedor` (`UP_Cod_Proveedor`, `UP_Direción`, `UP_Telefono`, `UP_Contraseña`, `UP_Correo_Electronico`, `UP_Nomb_Usuario`) VALUES
(1, 'Calle 20 #82-52 ', 3105222, 'tiktak78', 'kai75@gmail.com', ' Kai'),
(2, ' 87A Bis A - Cl 59 Sur', 315456123, 'ajajajak899', 'bik55@gmail.com', 'Biktor'),
(3, '87A Bis A - CL 61A Sur', 2147483647, '98745621', 'bas79655@gmail.com', 'Bastian'),
(4, 'Cra. 81 #77 51', 2147483647, '123456789', 'er4521@gmail.com', 'Earl'),
(5, 'Cl. 133 #27', 2147483647, '852147369', 'emi8520@gmail.com', 'Émile');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `facturación`
--
ALTER TABLE `facturación`
  ADD PRIMARY KEY (`F_Num_Facturacion`),
  ADD KEY `UC_Cod_Cliente` (`UC_Cod_Cliente`);

--
-- Indices de la tabla `formulas`
--
ALTER TABLE `formulas`
  ADD PRIMARY KEY (`FL_Num_Formula`),
  ADD KEY `P_Cod_Producto` (`P_Cod_Producto`);

--
-- Indices de la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`I_Num_Registro`),
  ADD KEY `F_Num_Facturacion` (`F_Num_Facturacion`,`P_Cod_Producto`),
  ADD KEY `P_Cod_Producto` (`P_Cod_Producto`);

--
-- Indices de la tabla `inventario_materia_prima`
--
ALTER TABLE `inventario_materia_prima`
  ADD PRIMARY KEY (`IMP_Num_regis_Mat_prima`),
  ADD KEY `UP_Cod_Provedor` (`UP_Cod_Provedor`),
  ADD KEY `IMP_Cod_producto` (`MP_Cod_Mat_Prim`),
  ADD KEY `MP_Cod_Mat_Prim` (`MP_Cod_Mat_Prim`),
  ADD KEY `UA_Cod_administrativo` (`UA_Cod_administrativo`);

--
-- Indices de la tabla `materias primas`
--
ALTER TABLE `materias primas`
  ADD PRIMARY KEY (`MP_Cod_Mat_Prim`),
  ADD KEY `FL_Num_Formula` (`FL_Num_Formula`),
  ADD KEY `IMP_Num_regis_Mat_prima` (`IMP_Num_regis_Mat_prima`);

--
-- Indices de la tabla `producción`
--
ALTER TABLE `producción`
  ADD PRIMARY KEY (`PCC_Cod_Produccion`),
  ADD KEY `IMP_Num_regis_Mat_prima` (`IMP_Num_regis_Mat_prima`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`P_Cod_Producto`),
  ADD KEY `UA_Cod_administrativo` (`UA_Cod_administrativo`),
  ADD KEY `PCC_Cod_Produccion` (`PCC_Cod_Produccion`);

--
-- Indices de la tabla `rol usuario`
--
ALTER TABLE `rol usuario`
  ADD PRIMARY KEY (`RU_Cod_Rol`);

--
-- Indices de la tabla `usuario-administrativo`
--
ALTER TABLE `usuario-administrativo`
  ADD PRIMARY KEY (`UA_Cod_administrativo`),
  ADD KEY `Cod_rol` (`Cod_rol`);

--
-- Indices de la tabla `usuario_cliente`
--
ALTER TABLE `usuario_cliente`
  ADD PRIMARY KEY (`UC_Cod_Cliente`);

--
-- Indices de la tabla `usuario_proveedor`
--
ALTER TABLE `usuario_proveedor`
  ADD PRIMARY KEY (`UP_Cod_Proveedor`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `facturación`
--
ALTER TABLE `facturación`
  ADD CONSTRAINT `facturación_ibfk_1` FOREIGN KEY (`UC_Cod_Cliente`) REFERENCES `usuario_cliente` (`UC_Cod_Cliente`);

--
-- Filtros para la tabla `formulas`
--
ALTER TABLE `formulas`
  ADD CONSTRAINT `formulas_ibfk_1` FOREIGN KEY (`P_Cod_Producto`) REFERENCES `producto` (`P_Cod_Producto`);

--
-- Filtros para la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD CONSTRAINT `inventario_ibfk_1` FOREIGN KEY (`P_Cod_Producto`) REFERENCES `producto` (`P_Cod_Producto`),
  ADD CONSTRAINT `inventario_ibfk_2` FOREIGN KEY (`F_Num_Facturacion`) REFERENCES `facturación` (`F_Num_Facturacion`);

--
-- Filtros para la tabla `inventario_materia_prima`
--
ALTER TABLE `inventario_materia_prima`
  ADD CONSTRAINT `inventario_materia_prima_ibfk_1` FOREIGN KEY (`UP_Cod_Provedor`) REFERENCES `usuario_proveedor` (`UP_Cod_Proveedor`),
  ADD CONSTRAINT `inventario_materia_prima_ibfk_2` FOREIGN KEY (`MP_Cod_Mat_Prim`) REFERENCES `materias primas` (`MP_Cod_Mat_Prim`),
  ADD CONSTRAINT `inventario_materia_prima_ibfk_3` FOREIGN KEY (`UA_Cod_administrativo`) REFERENCES `usuario-administrativo` (`UA_Cod_administrativo`);

--
-- Filtros para la tabla `materias primas`
--
ALTER TABLE `materias primas`
  ADD CONSTRAINT `materias primas_ibfk_1` FOREIGN KEY (`FL_Num_Formula`) REFERENCES `formulas` (`FL_Num_Formula`);

--
-- Filtros para la tabla `usuario-administrativo`
--
ALTER TABLE `usuario-administrativo`
  ADD CONSTRAINT `usuario-administrativo_ibfk_1` FOREIGN KEY (`Cod_rol`) REFERENCES `rol usuario` (`RU_Cod_Rol`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
